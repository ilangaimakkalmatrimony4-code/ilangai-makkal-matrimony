# Ilangai Makkal Matrimony Android app (source project)

This Android Studio project wraps https://ilangaimakkalmatrimony.com/ in a simple Android app. It loads the live website, supports JavaScript and browser back navigation, shows a loading bar, and opens external links in the appropriate app/browser.

## Build an APK
1. Install Android Studio on a computer: https://developer.android.com/studio
2. Open this folder in Android Studio.
3. Allow Gradle sync and install the Android SDK requested by the project (compile SDK 35).
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location. For a signed release APK, use **Build > Generate Signed Bundle / APK**.

## Important
- This ZIP contains the Android Studio source project, not a prebuilt APK.
- Website login, registration, search, and payment features remain provided by the live website; this wrapper does not create a separate database or payment system.
- Before publishing, test registration, payment, WhatsApp/contact links, and privacy behavior on real devices. If the website uses file uploads, camera, or push notifications, those need additional Android integration.
